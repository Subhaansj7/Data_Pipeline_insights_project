# Databricks notebook source
raw_folder_path='/mnt/formula1dlil/raw'
processed_folder_path='mnt/formula1dlil/processed'
presentation_folder_path='mnt/formula1dlil/presentation'

# COMMAND ----------

