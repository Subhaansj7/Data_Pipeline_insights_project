# Databricks notebook source
# MAGIC %md
# MAGIC ###Read all data as required
# MAGIC

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

drivers_df = spark.read.parquet("/mnt/formula1dlil/processed/drivers") \
    .withColumnRenamed("number", "driver_number") \
    .withColumnRenamed("name", "driver_name") \
    .withColumnRenamed("nationality", "driver_nationality")

# COMMAND ----------

constructors_df=spark.read.parquet("/mnt/formula1dlil/processed/constructors") \
    .withColumnRenamed("name","team")

# COMMAND ----------

circuits_df=spark.read.parquet("/mnt/formula1dlil/processed/circuits")\
    .withColumnRenamed("location","circuit_location")

# COMMAND ----------

races_df = spark.read.parquet("/mnt/formula1dlil/processed/races") \
    .withColumnRenamed("name", "race_name") \
    .withColumnRenamed("race_timestamp", "race_date")

# COMMAND ----------

results_df=spark.read.parquet("/mnt/formula1dlil/processed/results")\
    .withColumnRenamed("time","race_time")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Join races to circuits

# COMMAND ----------

race_circuits_df = races_df.join(circuits_df, races_df.circuit_id == circuits_df.circuit_id, "inner") \
    .select(races_df.race_id, races_df.race_year, races_df.race_name, races_df.race_date, circuits_df.circuit_location)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Join results to other dataframes

# COMMAND ----------

race_results_df=results_df.join(race_circuits_df,results_df.race_id==race_circuits_df.race_id)\
                          .join(drivers_df,results_df.driver_id==drivers_df.driver_id)\
                          .join(constructors_df,results_df.constructor_id==constructors_df.constructor_id)


# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df = race_results_df.select("race_year", "race_name", "race_date", "circuit_location", "driver_number", "driver_nationality","driver_name" , "team", "grid", "fastest_lap", "race_time", "points","position")\
                          .withColumn("created_date",current_timestamp())

# COMMAND ----------

final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_presentation.race_result")

# COMMAND ----------

